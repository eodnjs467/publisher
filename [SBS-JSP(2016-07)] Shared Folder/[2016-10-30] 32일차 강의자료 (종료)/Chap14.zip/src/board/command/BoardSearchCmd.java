package board.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import board.model.*;

public class BoardSearchCmd implements BoardCmd {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		BoardDAO dao = new BoardDAO();
		String searchOption = request.getParameter("searchOption");
		String searchWord 	= request.getParameter("searchWord");
		
		ArrayList<BoardDTO> list = dao.boardSearch(searchOption, searchWord);
		
		request.setAttribute("boardList", list);
	}
}
