package board.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class BoardUpdatePasswordCmd implements BoardCmd{
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String inputNum = request.getParameter("num");
		request.setAttribute("num", inputNum);
	}
}
